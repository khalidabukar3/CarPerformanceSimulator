# Lib Folder

This README exists, so the folder shows up in source control like git. This
file is not needed and can be safely deleted. 

That said, as a reminder, if you would like your project to compile, you should
put all your `.jar` files in this directory. At the very least, this directory
should contain the `components.jar` file, so the source code will compile.
